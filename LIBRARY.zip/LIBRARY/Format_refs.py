#!/usr/bin/python
import sys
import os
from operator import itemgetter
import copy
import commands

fh=open("Primer_reference_HOMO_SAPIENS_IGHV.txt","r")
ids_found = {}
for l in fh:
  if(l[0]!="#"):
    l=l.strip().split()
    ids_found[l[0]]=1
fh.close()

fh=open("Reference_nn_HOMO_SAPIENS_IGHV.fasta","r")
for l in fh:
  if(l[0]==">"):
    l=l.strip().replace(">","")
    if(l not in ids_found):
      c=commands.getoutput("grep \'"+l.replace("*",'\*')+"\' Reference_nn_HOMO_SAPIENS_IGHV.fasta -A1")
      print c

fh.close()








