#!/usr/bin/python
import sys
import os
import commands

def fasta_iterator(fh):
  while True:
    line = fh.readline()
    if line.startswith('>'): break  
  while True:
    header = line[1:-1].rstrip()
    sequence = fh.readline().rstrip()
    while True:
      line = fh.readline()
      if not line: break
      if line.startswith('>'): break
      sequence += line.rstrip()
    yield(header, sequence)
    if not line: return

def Get_trimmed_references_left_end_retained(input_file, output_file, n):
  fh=open(input_file,"r")
  out=""
  for header,sequence in fasta_iterator(fh):
    out = out+">"+header+"\n"+sequence[len(sequence)-n:len(sequence)]+"\n"
  fh.close()
  fh=open(output_file, "w")
  fh.write(out)
  fh.close()
  os.system("formatdb -i "+output_file+" -pF")
  return()

input_file = "Reference_nn_HOMO_SAPIENS_V.fasta"
n = 55
output_file = input_file.replace(".fasta","_last_"+str(n)+"bp.fasta")

Get_trimmed_references_left_end_retained(input_file, output_file, n)




